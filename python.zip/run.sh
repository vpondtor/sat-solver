#!/bin/bash

# Python solver
python3 solver.py $1